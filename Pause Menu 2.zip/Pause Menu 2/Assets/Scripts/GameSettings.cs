﻿public class GameSettings {
	public float musicVolume;
	public int resolutionIndex;
}
